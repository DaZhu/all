﻿var VideoMouseOutTimer = null;
var ImgMouseOutTimer = null;
var type_share_link = 0;
var type_share_single_Image = 1;
var type_share_media = 2;
var type_share_select_content = 3;
var type_share_article = 4;

(function (W, D) {
	$(D).ready(function () { // DOM ready
		$('img').each(function (i, imgelem) { // picture hover, show a float button
			$(imgelem).hover(function (E) { // hover function
				//console.log('in image');
				var imgurl = $(this).get(0).src;
				var btn = $("<div class='WeiboShrImgBtn'/>");
				btn.text("ShareImage");
				btn.offset({'left': $(this).offset().left + $(this).width() - 1, 'top': W.scrollY + E.clientY});
				btn.click(function () {
					chrome.runtime.sendMessage({
						'type': type_share_single_Image, 
						'url' :D.baseURI,
						'title' : D.title,
						'media' : imgurl,
						'content' : ''
						},
						function (response){}
					);
				});
				btn.hover(
					function(E) {
						//console.log('hove button');
						if (ImgMouseOutTimer) {
							clearTimeout(ImgMouseOutTimer);
							ImgMouseOutTimer = null;
						}
					},
					function(E) { // out share button
						//console.log('out button');
						setTimeout(function () {
							$('.WeiboShrImgBtn').remove();
						}, 5);
					}
				);
				btn.appendTo('body');
			},
			function(E) { // out image
				//console.log('out image');
				ImgMouseOutTimer = setTimeout(function () {
					clearTimeout(ImgMouseOutTimer);
					ImgMouseOutTimer = null;
					$('.WeiboShrImgBtn').remove();
				}, 10);
			});
		});

		function CheckIfVideoElem(element) {
			if (element && element.type) {
				var eletype = element.type;
				if (eletype && (
				// 视频
				(eletype === "application/x-shockwave-flash") || // flash
				(eletype === "application/vnd.rn-realmedia") || // .rm
				(eletype === "video/vnd.rn-realvideo") || // .rv
				(eletype === "video/x-flv") || // flv
				(eletype === "video/x-ms-wmv") || // wmv
				(eletype === "video/x-msvideo") || // avi
				(eletype === "video/mpeg") || // mp2, mpa, mpe, mpeg, mpg, mpv2
				(eletype === "video/quicktime") || // mov, qt
				(eletype === "video/x-la-asf") || // lsf, lsx
				(eletype === "video/x-ms-asf") || // asf, asr, asx
				(eletype === "video/x-sgi-movie") || // movie
				(eletype === "video/3gpp") || // 3gp
				(eletype === "video/mp4") // mp4
				))
				{
					return true;
				}
				return false;
			}
		}
		
		function CheckIfAudioElem(element) {
			if (element && element.type) {
				var eletype = element.type;
				if (eletype && (
					(eletype === "audio/x-wav")  || // wav
					(eletype === "audio/mpeg")  || // mp3
					(eletype === "audio/basic") || // au, snd
					(eletype === "audio/x-ms-wma")	|| // wma
					(eletype === "audio/mid")	|| // mid, rmi
					(eletype === "audio/midi")	|| // midi
					(eletype === "audio/x-aiff")	|| // aif, aifc, aiff
					(eletype === "audio/x-mpegurl")	|| // m3u
					(eletype === "audio/x-pn-realaudio") // ra, ram
				))
				{
					return true;
				}
				return false;
			}
		}
		
		$('embed').each(function (i, elem) { // embed hover
			if (CheckIfVideoElem(elem) || CheckIfAudioElem(elem)) {
				elem.addEventListener('mouseover', function(E) { // show a button to share
					var btn = $("<div class='WeiboShareFlashBtn'/>");
					btn.text('Share');
					btn.offset({'left': $(this).offset().left + $(this).width() - 1, 'top': E.clientY + W.scrollY});
					btn.click(function (){
						chrome.runtime.sendMessage({
							'type': type_share_media, 
							'url' :D.baseURI,
							'title' : D.title,
							'media' : '',
							'content' : ''
						}, function (response) {});
					});
					btn.hover(
						function(E){
							if (VideoMouseOutTimer) {
								clearTimeout(VideoMouseOutTimer);
								VideoMouseOutTimer = null;
							}
						},
						function (E){
							setTimeout(function () {
								$('.WeiboShareFlashBtn').remove();
							}, 5);
						}
					);
					btn.appendTo('body');
				});
				
				elem.addEventListener('mouseout', function(E) {
					VideoMouseOutTimer = setTimeout( function(){
						clearTimeout(VideoMouseOutTimer);
						VideoMouseOutTimer = null;
						$(".WeiboShareFlashBtn").remove();
					}, 10);
				});
			}
		});
		
		var mouseClkPosX = 0; // mouse click pos X
		var mouseClkPosY = 0; // mouse click pos Y
		var dragSelTimer = null; // drag selection timer function
		var thrClkSelTimer = null; // 3 clicks selection timer function
		var dblClkSelTimer = null; // double click timer function
		var mouseDownTimer = null;
		var dragSelFlag = false;
		var thrClkFlag = false;
		var dblClkSelFlag = false;
		$('body').mousedown(function (event){ // mouse down event
			if (event.button === 0) {  // left mouse
				mouseClkPosX = event.clientX;
				mouseClkPosY = event.clientY;
				mouseDownTimer = setTimeout(function (){ // remove share button
					clearTimeout(mouseDownTimer);
					mouseDownTimer = null;
					$('.ShareSelBtn').remove();
					$('.WeiboDblClkShrBtn').remove();
				},0);
			}
		});
		
		$('body').mouseup(function (event){ // mouse up event
			if (event.button === 0) { // left btn
				var mousex = event.clientX;
				var mousey = event.clientY;
				var pageUrl = D.baseURI;
				var Ypos = W.scrollY + mousey;
				if (dragSelFlag) {
					if (dragSelTimer) {
						clearTimeout(dragSelTimer);
						dragSelTimer = null;
					}
					dragSelFlag = false;
				} else {
					if (mouseClkPosX !== mousex || mouseClkPosY !== mousey) { // 拖动选择
						dragSelFlag = true;
						dragSelTimer = setTimeout(function() {
							dragSelFlag = false;
							clearTimeout(dragSelTimer);
							
							if (dblClkSelTimer) { // 停止双击
								clearTimeout(dblClkSelTimer);
								dblClkSelTimer = null;
							}
							if (thrClkSelTimer) { // 停止3击分享动作
								clearTimeout(thrClkSelTimer);
								thrClkSelTimer = null;
							}
							var imgList = new Array();
							var selectContent = W.getSelection(); // extract multimedias from selection fragment
							if (selectContent) {
								var range = selectContent.getRangeAt(0); 
								var selectionContents = range.cloneContents();
								if (selectionContents && selectionContents.childNodes) {
									$(selectionContents.childNodes).each(
										function(i, elem) {
											var img = $(elem).find('img');  // img
											if (img && img.size()) {
												img.each(function(i, imgElem) {
													imgList.push(imgElem.src);
												});
											}
										}
									);
								}
							}
							
							var sel_text = D.getSelection().toString();
							if (sel_text.length && sel_text.localeCompare('\n') != 0)
							{
								var btn = $("<div class='ShareSelBtn'>");
								btn.appendTo('body');
								btn.text('ShareSel');
								btn.offset({'left': mousex + 5, 'top': Ypos - 16});
								btn.mousedown(function (){
									if (mouseDownTimer) {
										clearTimeout(mouseDownTimer);
										mouseDownTimer = null;
									}
									$('.ShareSelBtn').remove();
									$('.WeiboDblClkShrBtn').remove();
									chrome.runtime.sendMessage({
											'type': type_share_select_content, 
											'url' :pageUrl,
											'title' : D.title,
											'media' : imgList,
											'content' : sel_text
										},
										function (response){}
									);
								});
							}
							dragSelTimer = null;
						}, 400); // drag select text timer
					} else {
						if (dblClkSelFlag) { // 3击选择段落
							dblClkSelFlag = false;
							if (dblClkSelTimer) {
								clearTimeout(dblClkSelTimer);
								dblClkSelTimer = null;
							}
							var sel_text = D.getSelection().toString();
							if (sel_text.length && sel_text.localeCompare('\n') != 0)
							{
								thrClkFlag = true;
								thrClkSelTimer = setTimeout(function () {
									thrClkFlag = false;
									clearTimeout(thrClkSelTimer);
									thrClkSelTimer = null;
									var btn = $("<div class='ShareSelBtn'>");
									btn.appendTo('body');
									btn.text('ShareSel');
									btn.offset({'left': mousex + 5, 'top': Ypos - 15});
									btn.mousedown(function (){
										if (mouseDownTimer) {
											clearTimeout(mouseDownTimer);
											mouseDownTimer = null;
										}
										$('.ShareSelBtn').remove();
										$('.WeiboDblClkShrBtn').remove();
										chrome.runtime.sendMessage({
												'type': type_share_select_content, 
												'url' :pageUrl,
												'title' : D.title,
												'media' : '',
												'content' : sel_text
											},
											function (response){}
										);
									});
								}, 300); // 3 cilck timer
							}
						} else { // normal click
							if (dblClkSelTimer) {
								clearTimeout(dblClkSelTimer);
								dblClkSelTimer = null;
							}
							if (thrClkSelTimer) {
								clearTimeout(thrClkSelTimer);
								thrClkSelTimer = null;
							}
							$('.ShareSelBtn').remove();
							$('.WeiboDblClkShrBtn').remove();
						}
					}
				}
			}
		});

		$('body').dblclick(function (event) {
			dblClkSelFlag = true;
			dblClkSelTimer = setTimeout( function () {
				dblClkSelFlag = false;
				clearTimeout(dblClkSelTimer);
				dblClkSelTimer = null;
			}, 200);
		});
	});
})(window, document);