﻿var type_share_link = 0;
var type_share_single_Image = 1;
var type_share_media = 2;
var type_share_select_content = 3;
var type_share_article = 4;

// 插件对象
var pluginObj = null;
pluginObj = document.getElementById("sina_share_plugin");

function onLoadProgress(HttpReqEvent) { // 图片加载进度
	if (HttpReqEvent.lengthComputable) {
		var percent = (HttpReqEvent.loaded / HttpReqEvent.total).toFixed(2) * 100;
		var strPercent = percent.toString() + "%";
	  }
}

var ShareImageList = [];
var WeiboShareOperator = {
	'TrimHeadTail': function (txtContent) { // 分享选中文字
		if (txtContent && txtContent.length) {
			return txtContent.replace(/^[\s\n]+|[\s\n]+$/g, ''); // 首尾空格与换行
		}
	},
	'SetImgData': function (task, url,data,ext) {
		if (task.length < 1 || url.length < 1 || typeof data !== "string" || data.length< 1) {
			return false;
		}
		if (pluginObj) {
			pluginObj.SetImgData(task, url, data, data.length, ext);
		}
	},
	'HttpGetImages': function (strShareId, imgUrlList) { // 分享图片
		if (typeof imgUrlList === 'string') {return};
		if (imgUrlList && imgUrlList.length) {
			var operatorThis = this;
			for (i = 0; i < imgUrlList.length; i++) {
				(function(shareId, url) {
					var xmlHttpReq = new XMLHttpRequest();
					xmlHttpReq.addEventListener("progress", onLoadProgress, false);
					xmlHttpReq.open("GET", imgUrlList[i], true );
					var imgExt = imgUrlList[i].substr(imgUrlList[i].lastIndexOf('.'));
					if (imgExt.length <4 || imgExt.length >5) {imgExt = ''} // 没有扩展名
					xmlHttpReq.send();
					xmlHttpReq.overrideMimeType("text/plain; charset=x-user-defined");
					xmlHttpReq.onreadystatechange = function () {
						if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) { // 4 = "loaded", 200 = 'ok'
							var picBlob = xmlHttpReq.responseText;
							var data = '';
							for (var i = 0; i < picBlob.length; ++i) {
								data += String.fromCharCode((picBlob[i].charCodeAt(0) & 0xff));
							}
							picBlob = window.btoa(data);
							operatorThis.SetImgData(shareId, url, picBlob, imgExt);
						}
					}
				})(strShareId, imgUrlList[i]);
			}
		}
	},
	'Share': function (type, url, title, media, content) {
		//this.TestShare(type, url, title, media, content);
		var imglist = '';
		if (typeof media !== 'string' && media.length) {
			imglist = media.join('|');
		} else {
			imglist = media;
		}
		var strShareId = new Date().getTime().toString();
		pluginObj.WebShare(strShareId, type, url, title, imglist, content);
		if (type === type_share_single_Image) {
			var imgUrl = media;
			this.HttpGetImages(strShareId, [imgUrl]);
		} else if (type === type_share_select_content){
			this.HttpGetImages(strShareId, media);
		}
	},
	'TestShare': function (type, url, title, media, content) {
		var strShareType = 'None';
		if (type === type_share_link) {
			strShareType = '分享链接';
		} else if (type === type_share_single_Image) {
			strShareType = '分享单图';
		} else if (type === type_share_media) {
			strShareType = '分享多媒体';
		} else if (type === type_share_select_content) {
			strShareType = '分享选中内容';
		} else if (type === type_share_article) {
			strShareType = '分享文章';
		} else {
			return;
		}
		
		var wnd = window.open('', 'abc');
		var d = wnd.document;
		d.write("分享类型:<br>" + strShareType + "<br>");
		d.write("<br>");
		d.write("网页URL:<br>" + url.toString()+ '<br>');
		d.write("<br>");
		d.write("标题:<br>" + title.toString()+ '<br>');
		d.write("<br>");
		if (type === type_share_media) {
			d.write("多媒体: <br>" + media.toString()+ '<br>');
		} else {
			var imgList = media.split(',');
			for (var i = 0; i < imgList.length; i++) {
				var img = imgList[i];
				this.HttpGetImages(imgList);
				d.write("图片: " + i.toString() + "<img src=\' " + img.toString()+ "\'></img><br>");
			}
		}
		d.write("<br>");
		if (type === type_share_article) {
			d.write("内容: <br>" );
			d.write("作者: <br>" + content.author + "<br>");
			d.write("发布时间: <br>" + content.pubtime + "<br>");
			d.write("正文: <br>" + content.text+ "<br>");
		} else {
			d.write("内容: <br>" + WeiboShareOperator.TrimHeadTail(content).toString()+ '<br>');
		}
		d.write("<br>");
	}
};

window.WeiboShareOperator = WeiboShareOperator;
