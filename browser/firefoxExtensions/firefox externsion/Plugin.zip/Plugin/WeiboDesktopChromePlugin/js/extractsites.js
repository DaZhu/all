var strBaidu_Tieba_url = /tieba\.baidu\.com/;
var strBaidu_Zhidao_url = /zhidao\.baidu\.com/;
var strSina_News_url = /news\.sina\.com\.cn/;

(function (W, D) {
	$(D).ready(function () {
		function sendShareArticle(url, title, media, content) {
			chrome.runtime.sendMessage(
				{
					'type': 4,
					'url' : url,
					'title' : title,
					'media' : media,
					'content' : content
				}, function (response){
				}
			);
		};
		var pageUrl = '';
		var artTitle = '';
		var mediaList = '';
		var theDoc = $(this);
		if (theDoc) {
			var pageUrl = theDoc.attr('URL');
			if (pageUrl) {
				var pub_time = '';
				var author_name = '';
				if (pageUrl.search(strSina_News_url) >= 0) { // 新浪新闻
					var Textblock = $(this).find('.blkContainer');
					if (Textblock.length) {
						var title = Textblock.find('#artibodyTitle'); // 新闻标题
						if (title.length && title.text()) {
							artTitle = title.text();
							// console.log(artTitle);
						}
						var time = Textblock.find('#pub_date'); // 发布日期
						if (time.length && time.text()) {
							pub_time = time.text();
							// console.log(pub_time);
						}
						
						var author = Textblock.find('#media_name'); //媒体名称
						if (author.length && author) {
							author_name = author.text();
							// console.log(author_name);
						}
						var textContent = '';
						var ArtiElem = Textblock.find('#artibody');
						if (ArtiElem.length) {
							var children = ArtiElem.children();
							children.each(function (i, elem){
								if (elem.tagName.toLowerCase() === 'script') {
									return true;
								}
								if ($(elem).text().length) {
									textContent = textContent + $(elem).text() + "<br>";
								}
							});
						}
						//console.log(textContent);
						sendShareArticle(
							pageUrl,
							artTitle,
							'',
							{
								'author': author_name,
								'pubtime': pub_time,
								'text': textContent
							}
						);
					}
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				} else if(false) {
				}
			}
		}
	});
})(window, document);