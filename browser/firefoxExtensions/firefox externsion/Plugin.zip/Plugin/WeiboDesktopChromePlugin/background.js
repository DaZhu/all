﻿var type_share_link = 0;
var type_share_single_Image = 1;
var type_share_media = 2;
var type_share_select_content = 3;
var type_share_article = 4;

var linkurl;
var picurl;
var audiourl;
var pageurl;
var selectedText;

(function (){
    linkurl = "";
    picurl = "";
	audiourl = "";
	pageurl = "";
    selectedText = "";
})();

// 插件对象
var pluginOperator = window.WeiboShareOperator;
chrome.contextMenus.create({
	type: "normal",
	title: "分享到微博",
	contexts:["all"], // attach context menu on all items
	onclick: function (info, tab) {
		pageurl = info.pageUrl;
		selectedText = info.selectionText;
		if (selectedText && selectedText.length) {
			pluginOperator.Share(type_share_select_content, tab.url, '', '', selectedText);
			return;
		}
		if (info.mediaType === "image") { // 单张图片
			var imgUrl = info.srcUrl;
			pluginOperator.Share(type_share_single_Image, tab.url, '', imgUrl);
			pluginOperator.HttpGetImages([imgUrl]);
		} else if (info.linkUrl && info.linkUrl.length) { // 链接
			pluginOperator.Share(type_share_link, info.linkUrl);
		} else { // 分享网页内容
			chrome.tabs.sendMessage(tab.id, {type: 'ShareArticle'},function(response) {});
		}
	}
});

chrome.runtime.onMessage.addListener(function (msg, sender, funcResp) {
	if (msg) {
		pluginOperator.Share(msg.type, msg.url, msg.title, msg.media, msg.content);
	}
});
