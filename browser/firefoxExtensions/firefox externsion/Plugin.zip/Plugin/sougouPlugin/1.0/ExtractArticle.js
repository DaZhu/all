function sendShareArticle(url, title, media, content) {
	sogouExplorer.extension.sendRequest(
		{
			'type': 4,
			'url' : url,
			'title' : title,
			'media' : media,
			'content' : content
		}, function (response){}
	);
};

function extractArticle(mainArticleBlkFilter, titleFilter, pubDateFilter, authorFilter, txtBodyFilter) {
	var artTitle = '';
	var mediaList = '';
	var pub_time = '';
	var author_name = '';
	var Textblock = $(document).find(mainArticleBlkFilter); // 主块容器
	if (Textblock.length) {
		console.log(Textblock);
		var title = Textblock.find(titleFilter); // 新闻标题
		if (title.length && title.text()) {
			artTitle = title.text();
			console.log(artTitle);
		}
		var time = Textblock.find(pubDateFilter); // 发布日期
		if (time.length && time.text()) {
			pub_time = time.text();
			console.log(pub_time);
		}
		var author = Textblock.find(authorFilter); //媒体名称
		if (author.length && author) {
			author_name = author.text();
			console.log(author_name);
		}
		var textContent = '';
		var ArtiElem = Textblock.find(txtBodyFilter); // 文章正文
		if (ArtiElem.length) {
			var children = ArtiElem.children();
			children.each(function (i, elem){
				if (elem.tagName.toLowerCase() === 'p' && $(elem).text().length) {
					textContent = textContent + $(elem).text() + "\n";
				} else if (elem.tagName.toLowerCase() === 'script') {
					return true;
				} else if ($(elem).text().length) {
					textContent = textContent + $(elem).text() + "\n";
				}
			});
		}
		//console.log(textContent);
		alert('aaaaa');
		sendShareArticle(
			document.URL,
			artTitle,
			'',
			{
				'author': author_name,
				'pubtime': pub_time,
				'text': textContent
			}
		);
	}
};

var siteInfoMap = [
	{ // 新浪
		site: /sina\.com\.cn/,
		mainBlockFilter: '.blkContainer',
		titleFilter:'#artibodyTitle',
		pubDateFilter:'#pub_date',
		authorFilter:'#media_name',
		txtBodyFilter:'#artibody'
	},
	{ // 百度贴吧
		site: /tieba\.baidu\.com/,
		mainBlockFilter: '',
		titleFilter:'',
		pubDateFilter:'',
		authorFilter:'',
		txtBodyFilter:''
	},
	{ // 百度知道
		site: /zhidao\.baidu\.com/,
		mainBlockFilter: '#qb-content',
		titleFilter:'.ask-title',
		pubDateFilter:'',
		authorFilter:'#ask-info',
		txtBodyFilter:'.wgt-best'
	},
	{ // 百度百科
		site: /baike\.baidu\.com/,
		mainBlockFilter: '',
		titleFilter:'',
		pubDateFilter:'',
		authorFilter:'',
		txtBodyFilter:''
	},
];

sogouExplorer.extension.onRequest.addListener(function(msg,sender,response) {
	alert('receive');
	if (msg.type === 'ShareArticle') {
		alert('share article');
		var nCount = siteInfoMap.length;
		for (var i = 0; i < nCount; i++) {
			var siteInfo = siteInfoMap[i];
			if (-1 !== document.URL.search(siteInfo.site)) {
				extractArticle(siteInfo.mainBlockFilter, siteInfo.titleFilter, siteInfo.pubDateFilter, siteInfo.authorFilter,siteInfo.txtBodyFilter);
				break;
			}
		}
	}
});